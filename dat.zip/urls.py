from django.urls import path
from . import views
from django.conf import settings
from django.contrib.staticfiles.urls import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns


urlpatterns = [
    path('', views.index, name='index'),

    path('about_kib_technologies/', views.about, name='about'),

    path('kib_technologies_products/', views.products, name='products'),

    path('kib_technologies_it_service', views.it_services, name='it_services'),
    path('kib_technologies_multimedia_marketing', views.multimedia_marketing, name='multimedia_marketing'),
    path('kib_technologies_cinema_branding', views.cinema_branding, name='cinema_branding'),
    path('kib_technologies_event_managment', views.event_managment, name='event_managment'),
    path('kib_technologies_digital_marketing', views.digital_marketing, name='digital_marketing'),
    path('kib_technologies_out_of_home_ads', views.out_of_home_ads, name='out_of_home_ads'),
   
    path('join_kib_technologies/', views.career, name='career'),

    path('contact_kib_technologies/', views.contact, name='contact'),
    
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
