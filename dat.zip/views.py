from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse, JsonResponse
from django.conf import settings

def index(request):
    return render(request,'index.html')

def about(request):
    return render(request, 'about.html')

def products(request):
    return render(request, 'products.html')

def it_services(request):
    return render(request, 'it_services.html')

def multimedia_marketing(request):
    return render(request, 'multimedia_marketing.html')

def cinema_branding(request):
    return render(request, 'cinema_branding.html')

def event_managment(request):
    return render(request, 'event_managment.html')

def digital_marketing(request):
    return render(request, 'digital_marketing.html')

def out_of_home_ads(request):
    return render(request, 'out_of_home_ads.html')

def career(request):
    return render(request,'career.html')

def contact(request):
    return render(request,'contact.html')
